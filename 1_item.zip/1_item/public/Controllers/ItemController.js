app.controller('itemController',['$scope','ItemService',function ($scope,ItemService) 
    { 
        $scope.items = []; 
        $scope.newItem = {};  
        $scope.editing = false;  
        $scope.editingItem = null; 
     
        // Add  
        $scope.addItem =  function() 
        { 
            ItemService.addItem($scope.newItem).then(function(response) 
            { 
                $scope.items.push(response.data); 
                $scope.newItem = {}; 
            }); 
        }; 
     
        // Retrieve  
        ItemService.getItems().then(function (response) 
        { 
            $scope.items = response.data; 
        }); 
     
        //Delete  
        $scope.deleteItem = function(id)     
        { 
            ItemService.deleteItem(id).then(function () 
            { 
                $scope.items = $scope.items.filter(item=>item._id !== id); 
            }); 
        }; 
     
        //Edit  
        $scope.editItem = function(item) 
        { 
            $scope.editing = true; 
            $scope.editingItem = angular.copy(item); 
        }; 
     
        //Update  
        $scope.updateItem = function() 
        { ItemService.updateItem($scope.editingItem._id,$scope.editingItem).then(function() 
                   { 
                       $scope.items = $scope.items.map(item=> 
                           { 
                               if(item._id === $scope.editingItem._id) 
                               { 
                                   return $scope.editingItem; 
                               } 
                           return item; 
                           }); 
                       $scope.editing = false; 
                       $scope.editingItem = null; 
                   }); 
        }; 
}]); 