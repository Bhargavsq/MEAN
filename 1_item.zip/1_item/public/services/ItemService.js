app.factory('ItemService',['$http',function ($http) 
    { 
        var baseURL = 'http://localhost:4500/items'; 
        return { 
            getItems: function () //Retrieve all items from the server 
            { 
                return $http.get(baseURL); 
            }, 
            addItem: function (item) //Add new Item to the Server 
            { 
                return $http.post(baseURL, item); 
            }, 
            updateItem: function (id,item) //Update Item based on id 
            { 
                return $http.put(baseURL + '/' + id, item); 
            }, 
            deleteItem: function (id) //delete item based on id 
            { 
                return $http.delete(baseURL + '/' + id); 
            } 
        }; 
    }]); 