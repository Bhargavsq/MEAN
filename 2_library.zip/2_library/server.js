const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyparser = require('body-parser');
const cors = require('cors');
const port = 4500;

const app = express();
app.use(bodyparser.json());
app.use(cors());

app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb://localhost:27017/mean_crud');

const bookSchema = new mongoose.Schema({ title: String, author: String, published_year: Number });
const book = mongoose.model('book', bookSchema);

app.post('/books', (req, res) => {
    const newbook = new book(req.body);
    newbook.save().then(book => res.json(book))
        .catch((error) => res.status(400).json(error));
});

app.get('/books', (req, res) => {
    book.find().then(books => res.json(books))
        .catch((error) => res.status(400).json(error));
});

app.get('/books/:title', (req, res) => {
    const bookTitle = req.params.title;
    book.findOne({ title: bookTitle })
        .then(book => {
            if (book) {
                res.json(book);
            } else {
                res.status(404).json({ message: 'Book not found' });
            }
        })
        .catch(error => res.status(400).json(error));
});


app.put('/books/:id', (req, res) => {
    book.findByIdAndUpdate(req.params.id, req.body,
        { new: true }).then(book => res.json(book))
        .catch((error) => res.status(400).json(error));
});

app.delete('/books/:id', (req, res) => {
    book.findByIdAndDelete(req.params.id).then(() => res.json({ success: true }))
        .catch((error) => res.status(400).json(error));
});

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});