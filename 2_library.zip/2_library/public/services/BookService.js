app.factory('BookService',['$http',function ($http)
    {
        var baseURL = 'http://localhost:4500/books';
        return {
            getBooks: function () 
            {
                return $http.get(baseURL);
            },
            addBook: function (book) 
            {
                return $http.post(baseURL, book);
            },
            updateBook: function (id,book) 
            {
                return $http.put(baseURL + '/' + id, book);
            },
            deleteBook: function (id) 
            {
                return $http.delete(baseURL + '/' + id);
            },
            getBookByTitle: function (title) { 
                return $http.get(baseURL + '/' + title);
            }
        };
    }]);