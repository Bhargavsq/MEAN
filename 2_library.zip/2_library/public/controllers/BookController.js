app.controller('BookController', ['$scope', 'BookService', function ($scope, BookService) {
    $scope.books = [];
    $scope.newbook = {}; 
    $scope.editing = false;
    $scope.editingbook = null; 
    $scope.errors = {}; 
    $scope.searchTitle = ''; 
    $scope.searchedBook = null; 
    $scope.msg='';

    // validation
    const titleAuthorRegex = /^.{3,}$/; 
    const yearRegex = /^\d{4}$/; 

    // Validate book fields before adding/updating
    $scope.validateBook = function (book) {
        $scope.errors = {}; 

        // Title validation: must be at least 3 characters
        if (!titleAuthorRegex.test(book.title)) {
            $scope.errors.title = "Title must be at least 3 characters long.";
        }

        // Author validation: must be at least 3 characters
        if (!titleAuthorRegex.test(book.author)) {
            $scope.errors.author = "Author must be at least 3 characters long.";
        }

        // Published year validation: must be exactly 4 digits
        if (!yearRegex.test(book.published_year)) {
            $scope.errors.published_year = "Published year must be a 4-digit number.";
        }

        return JSON.stringify($scope.errors) === '{}';

    };

    // Add 
    $scope.addBook = function () {
        if ($scope.validateBook($scope.newbook)) {
            BookService.addBook($scope.newbook).then(function (response) {
                $scope.books.push(response.data);
                $scope.newbook = {}; // Reset new book form
            });
        }
    };

    // Retrieve 
    BookService.getBooks().then(function (response) {
        $scope.books = response.data;
    });

    // Delete 
    $scope.deleteBook = function (id) {
        BookService.deleteBook(id).then(function () {
            $scope.books = $scope.books.filter(book => book._id !== id);
        });
    };

    // Edit 
    $scope.editBook = function (book) {
        $scope.editing = true;
        $scope.editingbook = angular.copy(book);
    };

    // Update 
    $scope.updateBook = function () {
        if ($scope.validateBook($scope.editingbook)) { 
            BookService.updateBook($scope.editingbook._id, $scope.editingbook).then(function () {
                $scope.books = $scope.books.map(book => {
                    if (book._id === $scope.editingbook._id) {
                        return $scope.editingbook;
                    }
                    return book;
                });
                $scope.editing = false;
                $scope.editingbook = null; 
            });
        }
    };

     // Get book by title
     $scope.getBookByTitle = function () {
        BookService.getBookByTitle($scope.searchTitle).then(function (response) {
            $scope.searchedBook = response.data;
            $scope.msg='';
        }).catch(function () {
            $scope.searchedBook = null; 
            $scope.msg='No Such Book Found.';
        });
    };
}]);
